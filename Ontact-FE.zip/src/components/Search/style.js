import styled from 'styled-components';

export const S = {
  Header: styled.div`
    text-align: center;
  `,

  h1: styled.div`
    text-align: center;
    font-size: 90px;
    bottom: 100px;
    color: #ffffff;
    text-shadow: 0 0 5px #91a4cc, 0 0 7px #91a4cc;
    font-weight: bold;
  `,
};
