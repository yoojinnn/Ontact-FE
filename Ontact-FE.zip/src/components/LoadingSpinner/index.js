import React from 'react';

function LoadingSpinner() {
  return (
    <div className="lds-heart">
      <div></div>
    </div>
  );
}

export default LoadingSpinner;
